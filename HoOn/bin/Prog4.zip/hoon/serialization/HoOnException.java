/************************************************
 *
 * Author:      Quoc-Bao Huynh
 * Assignment:  Program 4
 * Class:       CSI 4321
 *
 ************************************************/
package hoon.serialization;

import java.io.Serializable;

/*
 * HoOnException
 *
 * 1.0
 *
 * March 21, 2017
 *
 * Copyright
 */
public class HoOnException extends Exception implements Serializable {
	
	/**
	 * Constructs a HoOn exception
	 * 
	 * @param message
	 *            exception message
	 * @param cause
	 *            exception cause
	 */
	public HoOnException(ErrorCode errorCode) {
		super(errorCode.getErrorMessage());
	}

	/**
	 * Constructs a HoOn exception
	 * 
	 * @param message
	 *            exception message
	 */
	HoOnException(ErrorCode errorCode, Throwable cause) {
		super(errorCode.getErrorMessage(), cause);
	}
	
}
