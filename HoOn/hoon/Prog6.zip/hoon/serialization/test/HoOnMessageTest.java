package hoon.serialization.test;

public class HoOnMessageTest {

	public static void main(String args[]){
		
		
	}
	
}
