/************************************************
 *
 * Author:      Quoc-Bao Huynh
 * Assignment:  Program 4
 * Class:       CSI 4321
 *
 ************************************************/
package hoon.serialization;

/*
 * HoOnMessage
 *
 * 1.0
 *
 * March 21, 2017
 *
 * Copyright
 */
public abstract class HoOnMessage {

	// Holds the queryId of the packet
	private long queryId;
	// Holds the ErrorCode of the packet
	protected ErrorCode errorCode;
	// A Response message is equivalent to 1 or true
	private static boolean response = true;
	// A Query message is equivalent to 0 or true
	private static boolean query = false;
	// The minimum response/query packet size
	private static int minPacketSize = 8;
	// The maximum query packet size
	private static int maxQPacketSize = 8;
	// the maximum response packet size
	private static int maxRPacketSize = 65507;
	// A Long query bit mask to mask the potential queryId
	private static long queryBitmask = 0xFFFFFFFF00000000L;
	// Signifies an invalid post after masked
	private static int invalidQueryId = 0;

	/**
	 * Deserialize HoOn Message header
	 * 
	 * @param buffer
	 *            bytes from which to deserialize
	 * @return Deserialized HoOn message
	 * @throws HoOnException
	 *             if deserialization or validation fails (treat null buffer
	 *             like empty array). Validation problems include
	 *             insufficient/excess bytes (PACKETTOOSHORT/LONG), incorrect
	 *             version (BADVERSION), bad reserve (NETWORKERROR), unexpected
	 *             error code (UNEXPECTEDERRORCODE), and unexpected type
	 *             (UNEXPECTEDPACKETTYPE)
	 */
	public static HoOnMessage decode(byte[] buffer) throws HoOnException {
		// Check if byte array is null
		if (buffer == null) {
			throw new HoOnException(ErrorCode.PACKETTOOSHORT);
		}
		// Check if packet is too small
		if (buffer.length < minPacketSize) {
			throw new HoOnException(ErrorCode.PACKETTOOSHORT);
		}
		// Check version
		if (!MessageInput.checkVersion(buffer)) {
			throw new HoOnException(ErrorCode.BADVERSION);
		}
		// Query or Response
		boolean QR = MessageInput.getQR(buffer);
		if (QR == response) {
			// Check for response size
			if (buffer.length > maxRPacketSize) {
				throw new HoOnException(ErrorCode.PACKETTOOLONG);
			}
			return new HoOnResponse(buffer);
		} else if (QR == query) {
			// check for query response size
			if (buffer.length > maxQPacketSize) {
				throw new HoOnException(ErrorCode.PACKETTOOLONG);
			}
			return new HoOnQuery(buffer);
		} else {
			throw new HoOnException(ErrorCode.UNEXPECTEDPACKETTYPE);
		}

	}

	/**
	 * Serialize the HoOn message
	 * 
	 * @return serialized HoOn message
	 * @throws HoOnException
	 *             if error during serialization
	 */
	public abstract byte[] encode() throws HoOnException;

	/**
	 * Set the message query ID
	 * 
	 * @param queryId
	 *            the new query ID
	 * @throws IllegalArgumentException
	 *             if the given ID is out of range
	 */
	public void setQueryId(long queryId) {
		// Test whether queryId is out of range
		if (((queryId & queryBitmask) != invalidQueryId || queryId < 0)) {
			throw new IllegalArgumentException("Invalid queryId field");
		}
		this.queryId = queryId;
	}

	/**
	 * Get the message query ID
	 * 
	 * @return current query ID
	 */
	public long getQueryId() {
		return this.queryId;
	}

	/**
	 * Get the message error code
	 * 
	 * @return message error code
	 */
	public ErrorCode getErrorCode() {
		return errorCode;
	}

}
