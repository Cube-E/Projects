package hoon.serialization.test;


public class HoOnMainTest {
	
	
	public static void main(String args[])  {
		byte[] a = new byte[255];
		
		for(int i = 0; i < 24; i++){
			a[i] = 69;
		}
		System.out.println(a.length);
	}
	

}
