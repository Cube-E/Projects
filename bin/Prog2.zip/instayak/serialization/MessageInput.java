/************************************************
 *
 * Author:      Quoc-Bao Huynh
 * Assignment:  Program 0
 * Class:       CSI 4321
 *
 ************************************************/
package instayak.serialization;

import java.io.*;

public class MessageInput {

	//The inputstream wrapper
	private InputStreamReader sin;

	/**
	 * Constructs an input source from an InputStream
	 * 
	 * @param in
	 *            byte input source
	 */
	public MessageInput(InputStream in) {
		try {
			sin = new InputStreamReader(in, "ISO8859-1");
		} catch (NullPointerException e) {
			sin = null;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Parses till a space is reached
	 * 
	 * @return String the token read in till the space
	 * @throws IOException
	 *             if error in opening stream
	 * @throws InstaYakException
	 *             if a '\n' is not reached
	 */
	public String getTokenTillSpace() throws InstaYakException, IOException {
		if (sin == null) {
			throw new IOException("null inputStream");
		}
		// int to hold the currently read in character
		int ch;
		// set if a space is encountered. to exit loop
		boolean flag = false;
		String op = "";
		// Read one byte at a time.
		while (!flag && ((ch = sin.read()) > -1)) {
			// Check for ' ' or '\r'.
			if ((char) ch == ' ' || (char) ch == '\r') {
				flag = true;
			} else {
				op = op + (char) ch;
			}
		}
		return op;
	}

	/**
	 * Parses till a \r\n is reached
	 * 
	 * @return String the token read in till the new line
	 * @throws IOException
	 *             if error in opening stream
	 * @throws InstaYakException
	 *             if a '\n' is not reached
	 */
	public String getTokenTillNewLine() throws IOException, InstaYakException {
		if (sin == null) {
			throw new InstaYakException("Bad: ", new IOException("Null input stream"));
		}
		String msg = "";
		int ch;
		// Read one byte at a time.
		while (((ch = sin.read()) > -1)) {
			// Compare if the byte is a '\r' or \'n'
			if ((char) ch != '\n' && ((char) ch != '\r')) {
				msg = msg + (char) ch;
			}
			// Check for the "\r\n" frame.
			if ((char) ch == '\r') {
				if (validateNewLine()) {
					return msg;
				}
				// "\r\n" frame was not found.
				throw new InstaYakException("Invalid Message");
			}
			if ((char) ch == '\n') {
				throw new InstaYakException("Invalid Message");
			}

		}
		if (ch == -1) {
			throw new InstaYakException("End of stream");
		}
		return msg;
	}

	/**
	 * Reads a character and test if it is a '\n'
	 * 
	 * @throws IOException
	 *             if error in opening stream
	 * @return boolean represents whether a newline was reached
	 */
	public boolean validateNewLine() throws IOException {
		int ch;
		if ((ch = sin.read()) > -1) {
			if ((char) ch == '\n') {
				return true;
			}
		}
		// Invalid frame so read till the next new line
		boolean flag = false;
		while (!flag && ((ch = sin.read()) > -1)) {
			if ((char) ch == '\n') {
				flag = true;
			}
		}
		return false;
	}

}
