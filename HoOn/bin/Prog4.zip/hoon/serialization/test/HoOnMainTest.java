package hoon.serialization.test;

import java.nio.ByteBuffer;
import java.util.List;

import hoon.serialization.ErrorCode;
import hoon.serialization.HoOnException;
import hoon.serialization.MessageInput;

public class HoOnMainTest {
	
	
	public static void main(String args[]) throws HoOnException{
		System.out.println(ErrorCode.BADVERSION);
		//converting a byte array to 0s and 1s
		/*byte[] b = "ab".getBytes();
		
		for(byte a: b){
			System.out.println(Integer.toBinaryString(a & 255 | 256).substring(1));
			System.out.println(a);
		}
		
		
		byte[] b = {8,0,8,0,1};
		
		for(byte a: b){
			System.out.println(Integer.toBinaryString(a));
			System.out.println(Integer.toBinaryString(a & 255 | 256).substring(1));
			System.out.println(a);
		}
		
		char by = (char)b[0];
		System.out.println("character:" + by);

		
		//byte [] c = b;//Integer.toBinaryString(b[0]& 255 | 256).substring(1).getBytes();
		System.out.println("size: " + b.length);
		if(MessageInput.checkVersion(b)){
			System.out.println("good version");
		}
		else{
			System.out.println("bad version");
		}
		System.out.println("Size: " + b.length);
		///////////////////////////////
		if(MessageInput.getQR(b)){
			System.out.println("response");
		}
		else{
			System.out.println("query");
		}
		for(byte a: b){
			System.out.println(a);
		}
		System.out.println("al");
		long ab = MessageInput.readQueryId(b);
		System.out.println("This is it:" + Long.valueOf(ab));
		//System.out.println("This is the size of ab:"+ );
		b= MessageInput.removeOneByte(b);
		for(byte a:b){
			System.out.println(a);
		}
		System.out.println(MessageInput.readQueryId(b));
		b= MessageInput.removeFourBytes(b);
		for(byte a:b){
			System.out.println("lbla");
			System.out.println(a);
		}
		
		*/
		byte[] h = "hello".getBytes();
		byte[] a = "testing".getBytes();
		byte[] bas = "This is a really long post\nit even has newlines!".getBytes();
		byte[] na = "".getBytes();
		int size = h.length + a.length + 8 + bas.length + na.length;
		
		byte[] barr = new byte[size];
		ByteBuffer b = ByteBuffer.wrap(barr);
		b.putShort((short)h.length);
		b.put(h);
		b.putShort((short)a.length);
		b.put(a);
		b.putShort((short)na.length);
		b.put(na);
		b.putShort((short)bas.length);
		b.put(bas);
		for(int i = 0; i< barr.length; i++){
			System.out.println(barr[i]);
		}
		List<String> list = MessageInput.readPosts(barr, 4);
		for(String str: list){
			System.out.println(str);
		}
		
		
	}
	

}
