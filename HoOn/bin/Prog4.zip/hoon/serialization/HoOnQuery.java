/************************************************
 *
 * Author:      Quoc-Bao Huynh
 * Assignment:  Program 4
 * Class:       CSI 4321
 *
 ************************************************/
package hoon.serialization;

import java.nio.ByteBuffer;

/*
 * HoOnQuery
 *
 * 1.0
 *
 * March 21, 2017
 *
 * Copyright
 */
public class HoOnQuery extends HoOnMessage {

	// The bitmask for the number of posts read in
	private int numPostBitmask = 0xFFFF0000;
	// The size of a query packet
	private int queryPacketSize = 8;
	// Holds the number of posts
	private int requestedPostNum;
	// Signifies an invalid post after masked
	private static int invalidPostNum = 0;
	// The version and query to be put into the array
	private static int versionPlusQuery = 32;
	// The error code to be put into the array
	private static int queryErrorCode = 0;

	/**
	 * Creates a new HoOn query given individual elements
	 * 
	 * @param queryId
	 *            ID for query
	 * @param requestedPosts
	 *            Number of requested posts
	 * @throws IllegalArgumentException
	 *             If the queryId or requestedPosts are outside the allowable
	 *             range
	 */
	public HoOnQuery(long queryId, int requestedPosts) throws IllegalArgumentException {
		setQueryId(queryId);
		setRequestedPosts(requestedPosts);
	}

	/**
	 * Deserialize HoOn query
	 * 
	 * @param buffer
	 *            bytes from which to deserialize
	 * @throws HoOnException
	 *             if deserialization fails (treat null buffer like empty array)
	 */
	public HoOnQuery(byte[] buffer) throws HoOnException {
		if (buffer == null || buffer.length == 0) {
			throw new HoOnException(ErrorCode.UNEXPECTEDPACKETTYPE);
		}
		// check ErrorCode field. Should be NOERROR
		if (MessageInput.readErrCode(buffer) != ErrorCode.NOERROR.getErrorCodeValue()) {
			throw new HoOnException(ErrorCode.NETWORKERROR);
		}
		// get query id and remove the queryId bytes
		setQueryId(MessageInput.readQueryId(buffer));
		setRequestedPosts(MessageInput.readNumberPosts(buffer));
	}

	/**
	 * Overrides the toString class
	 */
	public String toString() {
		// return "Version: 2\nPacket Type: Query\nErrorCode: " +
		// getErrorCode().getErrorCodeValue() + "\nQueryId: " + getQueryId() +
		// "\nRequested Posts: " + getRequestedPosts();
		return "QueryId: " + getQueryId() + "\nRequested Posts: " + getRequestedPosts();
	}

	/**
	 * Get the number of requested posts in the message
	 * 
	 * @return current number of requested posts
	 */
	public int getRequestedPosts() {
		return requestedPostNum;
	}

	/**
	 * Set the number of requested posts in the message
	 * 
	 * @param requestedPosts
	 *            new number of requested posts
	 * @throws IllegalArgumentException
	 *             if number of requested posts out of range
	 */
	public void setRequestedPosts(int requestedPosts) throws IllegalArgumentException {
		if (((requestedPosts & numPostBitmask) != invalidPostNum) || requestedPosts < 0) {
			throw new IllegalArgumentException("Invalid requestedPost field");
		}
		this.requestedPostNum = requestedPosts;
	}

	/**
	 * overrides HoOnQuery encode
	 */
	@Override
	public byte[] encode() throws HoOnException {
		try {
			byte[] b = new byte[queryPacketSize];
			ByteBuffer qBuffer = ByteBuffer.wrap(b);
			qBuffer.position(0);
			qBuffer.put((byte) versionPlusQuery);
			qBuffer.put((byte) queryErrorCode);
			qBuffer.putInt((int) getQueryId());
			qBuffer.putShort((short) getRequestedPosts());
			return qBuffer.array();
		} catch (Exception e) {
			throw new HoOnException(ErrorCode.NETWORKERROR, e.getCause());
		}

	}

	@Override
	/**
	 * Overrides equals
	 * 
	 * @param obj
	 *            an object to compare
	 * @return boolean representing whether it is equal
	 */
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj == this) {
			return true;
		}
		if (obj instanceof HoOnQuery) {
			HoOnQuery query = (HoOnQuery) obj;
			return this.requestedPostNum == query.getRequestedPosts() && this.getQueryId() == query.getQueryId()
					&& this.getErrorCode() == query.getErrorCode();
		}
		return false;
	}

	@Override
	/**
	 * Overrides hashcode of object
	 * 
	 * @return int representing the hashcode
	 */
	public int hashCode() {
		int result = 11;
		result = 29 * result + requestedPostNum;
		return result;
	}
}
