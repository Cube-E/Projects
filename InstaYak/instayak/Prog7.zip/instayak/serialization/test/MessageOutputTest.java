/************************************************
 *
 * Author:      Quoc-Bao Huynh
 * Assignment:  Program 0
 * Class:       CSI 4321
 *
 ************************************************/
package instayak.serialization.test;

import static org.junit.Assert.*;

/**
 * Created by QB on 1/18/2017.
 */
public class MessageOutputTest {

}