/************************************************
 *
 * Author:      Quoc-Bao Huynh
 * Assignment:  Program 4
 * Class:       CSI 4321
 *
 ************************************************/
package hoon.serialization;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.List;

/*
 * HoOnResponse
 *
 * 1.0
 *
 * March 21, 2017
 *
 * Copyright
 */
public class HoOnResponse extends HoOnMessage {
	// The maximum number of posts
	private static int maxNumPosts = 65535;
	// The maximum length of a post
	private static int maxPostLength = 65535;
	// The minimum response packet size
	private static int minResponseSize = 8;
	// The character set for each byte read in
	private static Charset charset = Charset.forName("US-ASCII");
	// The version and query to be put into the array
	private static int versionPlusResponse = 40;
	// Size of a post length in bytes
	private static int bytePostLength = 2;
	// Holds the number of posts
	private int postNum;
	// Holds the posts
	private List<String> posts;

	/**
	 * Creates a new HoOn response given individual elements
	 * 
	 * @param errorCode
	 *            error code for response
	 * @param queryId
	 *            ID for response
	 * @param posts
	 *            list of posts
	 * @throws IllegalArgumentException
	 *             If the queryId or post list are outside the allowable range
	 */
	public HoOnResponse(ErrorCode errorCode, long queryId, List<String> posts) throws IllegalArgumentException {
		setErrorCode(errorCode.getErrorCodeValue());
		setQueryId(queryId);
		setPosts(posts);
	}

	/**
	 * Deserialize HoOn response
	 * 
	 * @param buffer
	 *            bytes from which to deserialize
	 * @throws HoOnException
	 *             if deserialization fails (treat null buffer like empty array)
	 */
	public HoOnResponse(byte[] buffer) throws HoOnException {
		if (buffer == null || buffer.length == 0) {
			throw new HoOnException(ErrorCode.UNEXPECTEDPACKETTYPE);
		}
		// get errorcode
		try {
			setErrorCode(MessageInput.readErrCode(buffer));
		} catch (IllegalArgumentException e) {
			throw new HoOnException(ErrorCode.UNEXPECTEDERRORCODE, e.getCause());
		}
		// get queryId
		setQueryId(MessageInput.readQueryId(buffer));
		// get number of posts
		postNum = MessageInput.readNumberPosts(buffer);
		// Populate the list of posts
		setPosts(MessageInput.readPosts(buffer, postNum));

	}

	/**
	 * Overrides the toString class
	 */
	public String toString() {
		String str = "ErrorCode: " + errorCode + "\nQueryId: " + getQueryId() + "\nPosts:\n";
		for (int i = 0; i < posts.size(); i++) {
			// Subtract one so a new line is not put at the last post in the
			// list
			if (i != posts.size() - 1) {
				str += posts.get(i) + "\n";
			} else {
				str += posts.get(i);
			}
		}
		return str;

	}

	/**
	 * Get the response list of posts
	 * 
	 * @return current list of posts
	 */
	public List<String> getPosts() {
		return posts;
	}

	/**
	 * Set the response list of posts
	 * 
	 * @param posts
	 *            new list of posts
	 * @throws IllegalArgumentException
	 *             if (list is null or outside length range) OR (an individual
	 *             post is null or outside length range)
	 */
	public void setPosts(List<String> posts) throws IllegalArgumentException {
		if (posts == null || posts.size() > maxNumPosts) {
			throw new IllegalArgumentException();
		}
		for (String str : posts) {
			if (str == null || str.getBytes(charset).length > maxPostLength) {
				throw new IllegalArgumentException();
			}
		}
		this.posts = posts;

	}

	/**
	 * Set the response error value (0-7)
	 * 
	 * @param errorCodeValue
	 *            new error value
	 * @throws IllegalArgumentException
	 *             if the error code value is out of range
	 */
	public void setErrorCode(int errorCodeValue) throws IllegalArgumentException {
		if (errorCodeValue < 0 || errorCodeValue > 7 || errorCodeValue == 6) {
			throw new IllegalArgumentException("Bad ErrorCode");
		}
		errorCode = ErrorCode.getErrorCode(errorCodeValue);
	}

	/**
	 * overrides encode from HoOnMessage
	 */
	@Override
	public byte[] encode() throws HoOnException {
		try {
			int responsePacketSize = minResponseSize;
			for (String str : getPosts()) {
				responsePacketSize += bytePostLength;
				responsePacketSize += str.length();
			}
			byte[] b = new byte[responsePacketSize];
			ByteBuffer rBuffer = ByteBuffer.wrap(b);
			rBuffer.position(0);
			rBuffer.put((byte) versionPlusResponse);
			rBuffer.put((byte) getErrorCode().getErrorCodeValue());
			rBuffer.putInt((int) getQueryId());
			rBuffer.putShort((short) postNum);
			for (String str : posts) {
				byte[] temp = str.getBytes(charset);
				rBuffer.putShort((short) temp.length);
				rBuffer.put(temp);
			}
			return rBuffer.array();
		} catch (Exception e) {
			throw new HoOnException(ErrorCode.NETWORKERROR, e.getCause());
		}
	}

	@Override
	/**
	 * Overrides equals
	 * 
	 * @param obj
	 *            an object to compare
	 * @return boolean representing whether it is equal
	 */
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj == this) {
			return true;
		}
		if (obj instanceof HoOnResponse) {
			HoOnResponse response = (HoOnResponse) obj;
			boolean flag = true;
			List<String> t = this.getPosts();
			List<String> r = response.getPosts();
			for (int i = 0; i < t.size(); i++) {
				if (!(t.get(i).equals(r.get(i)))) {
					flag = false;
				}
			}
			for (int i = 0; i < r.size(); i++) {
				if (!(r.get(i).equals(t.get(i)))) {
					flag = false;
				}
			}

			return this.getErrorCode().getErrorCodeValue() == response.getErrorCode().getErrorCodeValue()
					&& this.getQueryId() == response.getQueryId() && flag;
		}
		return false;
	}

	@Override
	/**
	 * Overrides hashcode of object
	 * 
	 * @return int representing the hashcode
	 */
	public int hashCode() {
		int result = 11;
		result = 29 * result + postNum;
		return result;
	}

}
